from django.contrib import admin
from django.urls import path,include
from User_Master import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('',include(('User_Master.urls','user'))),
    path('book_app/',include(('book_app.urls','book_app'))),
    path('guide/',include(('guide.urls','guide'))),
    path('med/',include(('med.urls','med'))),
    path('Chemist_Master/',include(('Chemist_Master.urls','chemist'))),
    path('payment/', views.payment, name='payment'),
    path('paymenthandler/', views.paymenthandler, name='paymenthandler'),
]
