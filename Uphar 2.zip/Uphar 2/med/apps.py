from django.apps import AppConfig


class MedConfig(AppConfig):
    name = 'med'
