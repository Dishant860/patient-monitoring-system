from django.contrib import admin
from Chemist_Master.models import ChemistRegister

class ChemistRegisterAdmin(admin.ModelAdmin):
    list_display=['cid','chemistfname','chemistmname','chemistlname','chemistaddress','chemistcity','chemistarea','chemistpincode','chemistcontactno','chemistphoto']

admin.site.register(ChemistRegister,ChemistRegisterAdmin)
admin.site.site_header = 'Uphar Administration'                    # default: "Django Administration"
admin.site.index_title = 'Uphar Admin panel'                 # default: "Site administration"
admin.site.site_title = 'Uphar Admin' 