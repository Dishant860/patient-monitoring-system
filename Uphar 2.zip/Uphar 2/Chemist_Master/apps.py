from django.apps import AppConfig


class ChemistMasterConfig(AppConfig):
    name = 'Chemist_Master'
