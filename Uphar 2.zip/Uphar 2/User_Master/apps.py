from django.apps import AppConfig


class UserMasterConfig(AppConfig):
    name = 'User_Master'
