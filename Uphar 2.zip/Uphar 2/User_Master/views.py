from django.shortcuts import render,redirect,get_object_or_404
from django.http import request,HttpResponseRedirect,HttpResponse,JsonResponse
from django.contrib.auth import update_session_auth_hash
from django.contrib import messages
from django.db.models import Q

from .models import UserRegister,cart,UserQuery
from .forms import UserRegisterForm,UserQueryForm

from med.models import Medicine

from guide.models import guides

import csv

import random
#email
import smtplib, ssl


from django.shortcuts import render
import razorpay
from django.conf import settings
from django.views.decorators.csrf import csrf_exempt
from django.http import HttpResponseBadRequest
# from practice.decorator import status

# @status
# def signin(request):
#     if request.method=="POST":    
#         try:
#             m = UserRegister.objects.get(uid=request.POST['uid'])
            
#             if m.userpwd == request.POST['userpwd']:
#                 request.session['user'] = m.uid
#                 return HttpResponseRedirect('/Userindex/')

#             else:
#                 return HttpResponse("<h2><a href=''>You have entered wrong password </a></h2>")
#         except:
#             return HttpResponse("<h2><a href=''>no username found.</a></h2>")
#     return render(request,'signin1.html')

# User signin 

razorpay_client = razorpay.Client(
    auth=(settings.RAZOR_KEY_ID, settings.RAZOR_KEY_SECRET))
 
def signin(request):
    if request.POST:
        email = request.POST['uid']
        pass1 = request.POST['userpwd']
        try:
            valid = UserRegister.objects.get(uid=email,userpwd=pass1)
            if valid:
                request.session['user'] = email
                return redirect('/Userindex/')
            else:
                return render(request,'error.html')
        except:
            return render(request,'error.html')
            #  return redirect('/signin/')
    return render(request,'signin1.html')

#User logout
def logout(request):
    if 'user' in request.session.keys():
        del request.session['user']
        return redirect('user:index')
    return redirect('user:index')

#User index
def index(request):
    # if 'user' in request.session:
    #     return render(request,'index.html')
    # else:
    #     return redirect('user:index')
    return render(request,'index.html')


#User Index{This indexpage will open after doing signin}
def index1(request):
    if 'user' in request.session:
        qur=UserQueryForm(request.POST)
        if qur.is_valid():
            qur.save()
            messages.success(request,'Message sent..')
        return render(request,'index1.html',{'qur':qur})
    else:
        return redirect('user:signin')


# User register
def signup(request):
    obj=UserRegisterForm(request.POST)
    
    if obj.is_valid():
        obj.save()
        return HttpResponseRedirect('/signin/')
    return render(request,'signup.html',{'obj':obj})
    

# User can search for medicines using this function
def search(request):
    try:
        serch = request.GET.get('query')
    except:
        serch = None
    if  serch:
        med = guides.objects.all().filter(Q(mname__icontains= serch) | Q(drug__icontains = serch) | Q(symptoms__icontains = serch) | Q(diseases__icontains = serch) )
        data = {
            'med':med
        }
    else:
        data={}
    return render(request,'search1.html',data)

# Forgot Password

def forgot_pass(request):
    email = request.POST.get('email')
    request.session['username'] = email
    if email == None:
        return render(request,'email.html')
        
    print(email)
    otp = ''
    rand = random.choice('0123456789')
    rand1 = random.choice('0123456789')
    rand2 = random.choice('0123456789')
    rand3 = random.choice('0123456789')
    otp = rand + rand1 + rand2 + rand3
    print(otp)
    request.session['otp'] = otp


    port = 465
    context = ssl.create_default_context()
    server = smtplib.SMTP_SSL("smtp.gmail.com",port,context=context)
    server.login("UphaRProjecT@gmail.com","uphar007")
    server.sendmail("UphaRProjecT@gmail.com",email,otp)
    server.quit()
    return redirect('user:otpcheck')
        

    return render(request,'email.html')

def otpcheck(request):
    if request.session.has_key('otp'):
        otp = request.session['otp']
        try:
            otpobj = request.POST.get('otp')
            if otpobj == None:
                return render(request,'otp.html')
            if otp == request.POST.get('otp'):
                return redirect('user:newpassword')
            else:
                return HttpResponse("<a href = ''>Wrong OTP Entered.</a>")
        except:
            return redirect('user:signin')
    return render(request,'otp.html')

def newpassword(request):
    new_pass = request.POST.get('password')
    if request.method == 'POST':
        obj = UserRegister.objects.get(uid = request.session['username'])
        obj.userpwd = new_pass
        obj.save()
        return redirect('user:signin')
    return render(request,'forgotpassword.html')
#Add to cart 



def add_to_cart(request):
    if 'user' in request.session:
        data = request.session['user']
        ur = UserRegister.objects.get(uid=data)
        context={}
        items = cart.objects.filter(user = ur)
        context['items'] = items
        context['users'] = ur

        if request.method == "POST":
            mid = request.POST["mid"]
            qty = request.POST["qty"]
            # data = request.user.id
            is_exist =  cart.objects.filter(medicine__id = mid,user = ur,status= False)
            if len(is_exist)>0:
                context['msz'] = "Alredy in your cart"
                context['cls'] = "alert alert-warning"
            else:
                medicine = get_object_or_404(guides,id=mid)
                # usr = get_object_or_404(UserRegister,id=request.user.id)
                c = cart(user=ur ,medicine = medicine, quantity=qty)
                c.save()
                context['msz'] = "Added in your cart"
                context['cls'] = "alert alert-success"
              
        return render(request,'cart.html',context)
    else:
        return redirect('logout')

def get_cart_data(request):
    if 'user' in request.session:
        data = request.session['user']
        ur = UserRegister.objects.get(uid=data)
        items =  cart.objects.filter(user=ur, status=False)
        total,quantity = 0,0
        for i in items:
            total += float(i.medicine.package_price)*i.quantity
            quantity += float(i.quantity)
        request.session['pay_amount'] = total
            
        res = {
            "Total":total, 
            "quan":quantity
        }
        return JsonResponse(res)
    else:
        return redirect('logout')

def change_quan(request):
    if "quantity" in request.GET:
        cid = request.GET["cid"]
        qty = request.GET["quantity"]
        cart_obj = get_object_or_404(cart,id=cid)
        cart_obj.quantity = qty
        cart_obj.save()
        return HttpResponse(cart_obj.quantity )
    
    if "delete_cart" in request.GET:
        id =request.GET["delete_cart"]
        cart_obj = get_object_or_404(cart,id=id)
        cart_obj.delete()
        return HttpResponseRedirect('/cart/')

def payment(request):
    currency = 'INR'
    amount = request.session['pay_amount']*100  
 
    # Create a Razorpay Order
    razorpay_order = razorpay_client.order.create(dict(amount=amount,
                                                       currency=currency,
                                                       payment_capture='0'))
 
    # order id of newly created order.
    razorpay_order_id = razorpay_order['id']
    callback_url = 'paymenthandler/'
 
    # we need to pass these details to frontend.
    context = {}
    context['razorpay_order_id'] = razorpay_order_id
    context['razorpay_merchant_key'] = settings.RAZOR_KEY_ID
    context['razorpay_amount'] = amount
    context['currency'] = currency
    context['callback_url'] = callback_url
    context['amount'] = request.session['pay_amount']
    return render(request, 'payment.html', context=context)
 
 
# we need to csrf_exempt this url as
# POST request will be made by Razorpay
# and it won't have the csrf token.
@csrf_exempt
def paymenthandler(request):
 
    # only accept POST request.
    if request.method == "POST":
        try:
           
            # get the required parameters from post request.
            payment_id = request.POST.get('razorpay_payment_id', '')
            razorpay_order_id = request.POST.get('razorpay_order_id', '')
            signature = request.POST.get('razorpay_signature', '')
            params_dict = {
                'razorpay_order_id': razorpay_order_id,
                'razorpay_payment_id': payment_id,
                'razorpay_signature': signature
            }
 
            # verify the payment signature.
            result = razorpay_client.utility.verify_payment_signature(
                params_dict)
            if result is None:
                amount = 20000  # Rs. 200
                try:
 
                    # capture the payemt
                    razorpay_client.payment.capture(payment_id, amount)
 
                    # render success page on successful caputre of payment
                    return render(request, 'paymentsuccess.html')
                except:
 
                    # if there is an error while capturing payment.
                    return render(request, 'paymentfail.html')
            else:
 
                # if signature verification fails.
                return render(request, 'paymentfail.html')
        except:
 
            # if we don't find the required parameters in POST data
            return HttpResponseBadRequest()
    else:
       # if other than POST request is made.
        return HttpResponseBadRequest()